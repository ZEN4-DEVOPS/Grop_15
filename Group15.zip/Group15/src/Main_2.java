import java.util.Arrays;

public class Main_2 {
    public static void main(String[] names) {
       int[] numbers = {1, 7, 2, 4, 5, 6};
       SelectionSort.selectionSort(numbers);
       System.out.println(Arrays.toString(numbers));
   }
    
    
       
}
